

var AssesmentModule = angular.module('Assesment', ['ngStorage', 'ui.router']);