
app = angular.module('vod',[]);

// app.config(function ( $routeProvider, $locationProvider, $sceDelegateProvider) {
//     $sceDelegateProvider.resourceUrlWhitelist(['self', '**']);
// });

